# daily-report (example job, weekdays)

One job: read yesterday's numbers from a file you already produce and write a short report. It never sends, posts or deletes anything. ops/CONSTITUTION.md binds this run.

## Inputs (Reads)
- reports/metrics.csv: one row per day, written by your own export. Replace with your real source.
- ops/HANDOFF.md: open blockers that change what the report should flag.

## Process (Executes)
1. Date from the shell. `python3 tools/preflight.py daily-report`. Exit 1: write the ERROR lines to reports/run-log.md and stop.
2. Read the last two rows of reports/metrics.csv. Missing file or missing yesterday: write "not run" with the reason and stop.
3. Compute each change in code, not in your head. Round once, at the end.
4. Write reports/daily-YYYY-MM-DD.md: three lines, the numbers and their change, nothing invented.

## Outputs (Writes)
- reports/daily-YYYY-MM-DD.md.
- One line in reports/run-log.md: date, job, PASS or FAIL, the reason when FAIL.
- Nothing else. A message to the owner only when the run could not start.
