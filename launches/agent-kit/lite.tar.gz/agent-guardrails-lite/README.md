# Agent guardrails, lite

A small, free starting point for running a coding agent (built for Claude Code) on a schedule without watching it: a rulebook the agent reads before every run, a router that keeps each run's context small, and a preflight that stops the run when a check fails. One gate ships here, with tests that plant failures to check the gate still catches them.

This is the lite version of the ProofNotFluff Unattended Agent Kit. It is the pattern, not a sandbox: rules in a file are read by the model, and a model can still get them wrong. Hard limits belong in your agent's permission settings and your platform (separate accounts, read-only keys, spending caps, backups). The pattern makes the rules explicit, keeps them loaded, and makes a broken check stop the run instead of passing quietly.

## Quick start (five steps)

1. Copy these files into your repo (or use this repo as a template).
2. Edit `ops/CONSTITUTION.md`: fill in the angle brackets, delete what does not apply.
3. Run `python3 tools/preflight.py daily-report`. You should see `0 errors. The run may start.`
4. Replace `.claude/skills/daily-report/` with your first real job, one job per skill.
5. Start every scheduled prompt with: "Read CLAUDE.md and follow it."

Python 3.8 or later. No packages to install.

## What is in here

| File | What it does |
|---|---|
| `CLAUDE.md` | Layer 0, the router: what loads before a run, and the rules every run follows first. |
| `ops/HANDOFF.md` | Layer 1, live state: what is true right now, kept under 2 KB. |
| `ops/CONSTITUTION.md` | The fixed rules: money, accounts, sending, deleting, secrets. Only the owner changes it. |
| `ops/DECISIONS.md` | The owner's words, dated, so a rule always traces back to a person saying yes. |
| `.claude/skills/<job>/SKILL.md` | Layer 2, one job per skill, each with Inputs, Process and Outputs. |
| `tools/preflight.py` | The first command of every run. Any ERROR means exit 1 and the run stops. |
| `tools/context_gate.py` | The gate: a size cap on each layer and on the rules, a budget for the whole pre-run load, the three sections, and the router's two required lines, word for word. |
| `tools/test_gates.py` | Planted failures: 26 known-bad cases the gate must catch, every size limit tested at the limit, and 6 good cases it must pass (each limit one byte under, and the clean copy). |

## Try breaking it

Change one word in either required line of `CLAUDE.md`, or delete it, or wrap it in a comment, then run the preflight. It fails and says why. Put the line back.

A text check cannot judge what a sentence means, so it does not try. The two required lines must stay word for word; anything else you write in `CLAUDE.md` is up to you, and a contradicting sentence elsewhere is not caught.

## The full kit

The paid kit is in build. It is planned to add the gates for the things that actually cost money: a send gate (nothing leaves unless its template was approved and is unchanged), a spend and account rule set with a stop word, a delete guard, a secrets and personal-data scan, Claude Code permission presets and a hook that blocks the dangerous commands, a decisions log the gates read, a worked scheduled job end to end, and planted tests for every gate. Waitlist: https://proofnotfluff.com/unattended-agent-kit/

## Credit

The layered folder layout (Layer 0 router, Layer 1 workspace state, Layer 2 stage contracts) is adapted from the Interpretable Context Methodology by Jake Van Clief and David McDermott, MIT license: https://github.com/RinDig/Interpretable-Context-Methodology-ICM and https://arxiv.org/abs/2603.16021. The constitution, the preflight, the context budget gate and the planted-failure tests are ProofNotFluff additions. The authors are not affiliated with and have not reviewed this kit.

## License

MIT. See LICENSE. Provided as is under the MIT license. Not legal, security or financial advice; you are responsible for what your agent does. Try it on a copy before a repo you care about.

Claude and Claude Code are trademarks of Anthropic. ProofNotFluff is not affiliated with or endorsed by Anthropic.
