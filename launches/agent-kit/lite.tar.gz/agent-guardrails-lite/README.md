# Agent guardrails, lite

A small, free starting point for running a coding agent (built for Claude Code) on a schedule without watching it: a rulebook the agent reads before every run, a router that keeps each run's context small, and a preflight that stops the run when a check fails. One gate ships here, with tests that plant failures to prove the gate still catches them.

This is the lite version of the ProofNotFluff Unattended Agent Kit. It is the pattern, not a sandbox: rules in a file are read by the model, and a model can still get them wrong. Hard limits belong in your agent's permission settings and your platform (separate accounts, read-only keys, spending caps, backups). The pattern makes the rules explicit, keeps them loaded, and makes a broken check stop the run instead of passing quietly.

## Quick start (about 10 minutes)

1. Copy these files into your repo (or use this repo as a template).
2. Edit `ops/CONSTITUTION.md`: fill in the angle brackets, delete what does not apply.
3. Run `python3 tools/preflight.py daily-report`. You should see `0 errors. The run may start.`
4. Replace `.claude/skills/daily-report/` with your first real job, one job per skill.
5. Start every scheduled prompt with: "Read CLAUDE.md and follow it."

Python 3.8 or later. No packages to install.

## What is in here

| File | What it does |
|---|---|
| `CLAUDE.md` | Layer 0, the router: what loads before a run, and the rules every run follows first. |
| `ops/HANDOFF.md` | Layer 1, live state: what is true right now, kept under 2 KB. |
| `ops/CONSTITUTION.md` | The fixed rules: money, accounts, sending, deleting, secrets. Only the owner changes it. |
| `ops/DECISIONS.md` | The owner's words, dated, so a rule always traces back to a person saying yes. |
| `.claude/skills/<job>/SKILL.md` | Layer 2, one job per skill, each with Inputs, Process and Outputs. |
| `tools/preflight.py` | The first command of every run. Any ERROR means exit 1 and the run stops. |
| `tools/context_gate.py` | The gate: size caps per layer, a total budget, the three sections, and a router that names the rules and the preflight. |
| `tools/test_gates.py` | Planted failures: 9 known-bad copies the gate must catch, plus a clean copy it must pass. |

## Try breaking it

Delete the line in `CLAUDE.md` that names `ops/CONSTITUTION.md`, then run the preflight. It fails and says why. Put the line back.

## The full kit

The paid kit adds the gates for the things that actually cost money: a send gate (nothing leaves unless its template was approved and is unchanged), a spend and account rule set with a stop word, a delete guard, a secrets and personal-data scan, Claude Code permission presets and a hook that blocks the dangerous commands, a decisions log the gates read, a worked scheduled job end to end, and planted tests for every gate. Waitlist: <link to the offer page, added at launch>.

## Credit

The layered folder layout (Layer 0 router, Layer 1 workspace state, Layer 2 stage contracts) is the Interpretable Context Methodology by Jake Van Clief and David McDermott, MIT license: https://github.com/RinDig/Interpretable-Context-Methodology-ICM and https://arxiv.org/abs/2603.16021. The constitution, the preflight, the context budget gate and the planted-failure tests are ProofNotFluff additions.

## License

MIT. See LICENSE. Not legal, security or financial advice; you are responsible for what your agent does.
