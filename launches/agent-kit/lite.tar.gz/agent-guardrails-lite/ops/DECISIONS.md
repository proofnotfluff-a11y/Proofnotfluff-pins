# Decisions log

One entry per owner decision, newest last. The owner's exact words in quotes, with the date and time, then one line on what the decision allows. Agents apply these; only the owner changes them.

## Example, <YYYY-MM-DD HH:MM>
- [stated] Owner: "<exact words>"
- So: <what this allows, its limits, and its stop word>.
