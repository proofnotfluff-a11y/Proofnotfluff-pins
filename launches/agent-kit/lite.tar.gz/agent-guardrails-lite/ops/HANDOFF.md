# Handoff (Layer 1)

Live state only. Every run reads this before its skill. Keep it under 2 KB: move anything older than a week to ops/DECISIONS.md.

- Owner's standing words: none yet. Record them in ops/DECISIONS.md with the date, time and the exact words.
- Scheduled jobs: daily-report (example, weekdays). Add one line per job: name, schedule, where it runs.
- Open blockers: none.
- Next step: replace the example skill with your first real job, run `python3 tools/preflight.py daily-report`, then schedule it.
