#!/usr/bin/env python3
"""Context gate: what a scheduled run loads before it starts must stay small, must carry the rules, and must be
split one job per skill. Exit 0 on pass, 1 on any problem. Every line printed is "OK context: ..." or
"ERROR context: ...", so a run can grep for ERROR.

Layers (adapted from the Interpretable Context Methodology, MIT, arXiv 2603.16021):
  Layer 0  CLAUDE.md                      the router, under CAP_L0 bytes
  Layer 1  ops/HANDOFF.md                 live state, under CAP_L1 bytes
  Rules    ops/CONSTITUTION.md            the fixed rules, loaded before every run, under CAP_RULES bytes
  Layer 2  .claude/skills/<job>/SKILL.md  one job each, under CAP_SKILL bytes, with Inputs, Process and Outputs
  Budget   Layer 0 + Layer 1 + the rules + any one SKILL.md under BUDGET bytes, so nothing a run needs is cut
The budget sits below the sum of the caps, so it binds on its own.

The router must carry each line in REQUIRED word for word, as a line of its own, outside HTML comments and code
fences. A text check cannot judge what a sentence means, so it does not try: change a required line in any way,
remove it, comment it out or fence it, and the gate fails.

Usage: python3 tools/context_gate.py [--skill <job>] [--root <dir>]
"""
import argparse
import glob
import os
import re
import sys

L0, L1, RULES = "CLAUDE.md", os.path.join("ops", "HANDOFF.md"), os.path.join("ops", "CONSTITUTION.md")
CAP_L0 = CAP_L1 = 2048
CAP_RULES = 4096
CAP_SKILL = 5120
BUDGET = 10240
SECTIONS = ("## Inputs (Reads)", "## Process (Executes)", "## Outputs (Writes)")
REQUIRED = (
    "- Read ops/CONSTITUTION.md before anything else. It binds every run.",
    "- Run `python3 tools/preflight.py <job>` first. Exit 1 stops the run: report the ERROR lines to the owner "
    "and never edit a gate to make it pass.",
)


def size(root, rel):
    p = os.path.join(root, rel)
    return os.path.getsize(p) if os.path.isfile(p) else None


def live_lines(text):
    """The router's lines a model reads as instructions: HTML comments (closed or not) and fenced code removed."""
    text = re.sub(r"<!--.*?(?:-->|\Z)", "", text, flags=re.S)
    out, fenced = [], False
    for line in text.splitlines():
        if line.lstrip().startswith(("```", "~~~")):
            fenced = not fenced
            continue
        if not fenced:
            out.append(line.rstrip())
    return out


def check(root, skill=None):
    problems, loads = [], {}
    s0, s1 = size(root, L0), size(root, L1)
    for rel, s, cap in ((L0, s0, CAP_L0), (L1, s1, CAP_L1)):
        if s is None:
            problems.append(f"{rel} is missing")
        elif s >= cap:
            problems.append(f"{rel} is {s} bytes, the cap is under {cap}")
    if s0 is not None:
        lines = live_lines(open(os.path.join(root, L0), encoding="utf-8").read())
        for i, req in enumerate(REQUIRED, 1):
            if req not in lines:
                problems.append(f"{L0} lacks required line {i} word for word: {req[:48]}...")
    rules = size(root, RULES)
    if not rules:
        problems.append(f"{RULES} is missing or empty")
    elif rules >= CAP_RULES:
        problems.append(f"{RULES} is {rules} bytes, the cap is under {CAP_RULES}")
    skills = sorted(glob.glob(os.path.join(root, ".claude", "skills", "*", "SKILL.md")))
    names = [os.path.basename(os.path.dirname(p)) for p in skills]
    if not skills:
        problems.append("no .claude/skills/<job>/SKILL.md files")
    if skill and skill not in names:
        problems.append(f"skill {skill!r} has no .claude/skills/{skill}/SKILL.md")
    for p, name in zip(skills, names):
        rel = os.path.relpath(p, root)
        s = os.path.getsize(p)
        text = [t.rstrip() for t in open(p, encoding="utf-8").read().splitlines()]
        if s >= CAP_SKILL:
            problems.append(f"{rel} is {s} bytes, the cap is under {CAP_SKILL}")
        for sec in SECTIONS:
            if sec not in text:
                problems.append(f"{rel} lacks the section {sec!r}")
        total = (s0 or 0) + (s1 or 0) + (rules or 0) + s
        loads[name] = total
        if total >= BUDGET:
            problems.append(f"Layer 0 + Layer 1 + {RULES} + {rel} = {total} bytes, the budget is under {BUDGET}")
    return problems, loads, s0, s1, rules


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--skill")
    ap.add_argument("--root", default=os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    a = ap.parse_args()
    problems, loads, s0, s1, rules = check(a.root, a.skill)
    for p in problems:
        print(f"ERROR context: {p}")
    if problems:
        sys.exit(1)
    print(f"OK context: L0 {s0} B, L1 {s1} B, rules {rules} B, largest pre-run load {max(loads.values())} of {BUDGET} B")


if __name__ == "__main__":
    main()
