#!/usr/bin/env python3
"""Preflight: the first command every scheduled run executes. It runs each gate, then the planted-failure tests that
prove the gates still catch what they should. Any ERROR line means exit 1, and the router tells the run to stop and
report the ERROR lines to the owner instead of working around them.

Add your own gates to GATES: each is a command that prints OK or ERROR lines and exits 0 or 1.

Usage: python3 tools/preflight.py <job>
"""
import os
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def gates(job):
    py = sys.executable
    return [
        ("context", [py, os.path.join(ROOT, "tools", "context_gate.py"), "--skill", job]),
        ("gate-test", [py, os.path.join(ROOT, "tools", "test_gates.py")]),
    ]


def main():
    if len(sys.argv) != 2:
        print("usage: python3 tools/preflight.py <job>")
        sys.exit(2)
    job = sys.argv[1]
    failed = 0
    for name, cmd in gates(job):
        try:
            p = subprocess.run(cmd, capture_output=True, text=True, timeout=300, cwd=ROOT)
            out, code = (p.stdout + p.stderr).strip(), p.returncode
        except subprocess.TimeoutExpired:
            out, code = f"ERROR {name}: timed out", 1
        lines = out.splitlines() or [f"ERROR {name}: no output"]
        for line in lines:
            print(line)
        if code != 0 or any(l.startswith("ERROR") for l in lines):
            failed += 1
    if failed:
        print(f"preflight {job}: {failed} gate(s) failed. Stop the run and report the ERROR lines.")
        sys.exit(1)
    print(f"preflight {job}: 0 errors. The run may start.")


if __name__ == "__main__":
    main()
