#!/usr/bin/env python3
"""Planted failures: a gate you never see fail is a gate you cannot trust. This copies the repo to a throwaway folder,
plants one known failure at a time, runs the gate on the copy and confirms the gate catches it with the expected
message. It also confirms the clean copy passes, so the gate is not simply failing everything.

Add a case here every time you add a rule to a gate. Exit 0 when every case is right, 1 otherwise.

Usage: python3 tools/test_gates.py
"""
import os
import shutil
import subprocess
import sys
import tempfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
GATE = os.path.join(ROOT, "tools", "context_gate.py")
SKILL = os.path.join(".claude", "skills", "daily-report", "SKILL.md")


def write(root, rel, text, mode="w"):
    p = os.path.join(root, rel)
    os.makedirs(os.path.dirname(p) or ".", exist_ok=True)
    with open(p, mode, encoding="utf-8") as f:
        f.write(text)


def replace(root, rel, old, new):
    p = os.path.join(root, rel)
    text = open(p, encoding="utf-8").read()
    assert old in text, f"planting needs {old!r} in {rel}"
    write(root, rel, text.replace(old, new))


def pad(root, rel, to):
    """Grow a file to exactly `to` bytes."""
    p = os.path.join(root, rel)
    write(root, rel, "z" * (to - os.path.getsize(p)), "a")


# (name, how to plant it, the text the gate must print)
CASES = [
    ("router over its cap", lambda r: write(r, "CLAUDE.md", "x" * 2100, "a"), "CLAUDE.md is"),
    ("handoff over its cap", lambda r: write(r, os.path.join("ops", "HANDOFF.md"), "x" * 2100, "a"), "HANDOFF.md is"),
    ("router stops naming the constitution", lambda r: replace(r, "CLAUDE.md", "ops/CONSTITUTION.md", "ops/RULES.md"),
     "does not send runs to ops/CONSTITUTION.md"),
    ("router stops naming the preflight", lambda r: replace(r, "CLAUDE.md", "tools/preflight.py", "tools/start.py"),
     "does not send runs to tools/preflight.py"),
    ("constitution emptied", lambda r: write(r, os.path.join("ops", "CONSTITUTION.md"), ""), "CONSTITUTION.md is missing or empty"),
    ("skill loses its Outputs section", lambda r: replace(r, SKILL, "## Outputs (Writes)", "## Results"), "lacks the section"),
    ("skill over its cap", lambda r: write(r, SKILL, "y" * 5200, "a"), "the cap is under 5120"),
    # each layer stays under its own cap, but the three together pass the budget
    ("one load over the budget", lambda r: (pad(r, "CLAUDE.md", 2000), pad(r, os.path.join("ops", "HANDOFF.md"), 2000),
                                            pad(r, SKILL, 4400)), "the budget is under"),
]


def run_gate(root, skill="daily-report"):
    p = subprocess.run([sys.executable, GATE, "--root", root, "--skill", skill], capture_output=True, text=True)
    return p.returncode, p.stdout + p.stderr


def main():
    wrong = 0
    with tempfile.TemporaryDirectory() as tmp:
        clean = os.path.join(tmp, "clean")
        shutil.copytree(ROOT, clean, ignore=shutil.ignore_patterns(".git", "__pycache__"))
        code, out = run_gate(clean)
        if code != 0:   # planted cases mean nothing until the clean copy passes
            print("ERROR gate-test: the repo fails its own gate, so the planted cases were not run; fix the ERROR context lines first")
            sys.exit(1)
        code, out = run_gate(clean, skill="no-such-job")
        if code != 1 or "has no .claude/skills/no-such-job" not in out:
            wrong += 1
            print("ERROR gate-test: an unknown skill name was not caught")
        for i, (name, plant, expect) in enumerate(CASES):
            copy = os.path.join(tmp, f"case{i}")
            shutil.copytree(clean, copy)
            try:
                plant(copy)
            except (AssertionError, OSError) as e:
                wrong += 1
                print(f"ERROR gate-test: could not plant case {name}: {e}")
                continue
            code, out = run_gate(copy)
            if code != 1 or expect not in out:
                wrong += 1
                print(f"ERROR gate-test: planted case not caught: {name} (exit {code})")
    total = len(CASES) + 2
    if wrong:
        print(f"ERROR gate-test: {wrong} of {total} cases wrong")
        sys.exit(1)
    print(f"OK gate-test: {total} of {total} cases right (1 clean pass, {total - 1} planted failures caught)")


if __name__ == "__main__":
    main()
