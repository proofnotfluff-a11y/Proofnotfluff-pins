#!/usr/bin/env python3
"""Planted failures: a gate you never see fail is a gate you cannot trust. This copies the files the gate reads to a
throwaway folder, changes one thing at a time, runs the gate on the copy and checks the verdict:
  - every rule has a case that must FAIL, with the message the gate must print;
  - every size limit is tested at the limit (must fail) and one byte under it (must pass), so a limit that is raised,
    lowered or turned from "under" into "up to" is caught too;
  - the clean copy must pass, so the gate is not simply failing everything.
Add cases here every time you add a rule to a gate. Exit 0 when every case is right, 1 otherwise.

Usage: python3 tools/test_gates.py
"""
import os
import shutil
import subprocess
import sys
import tempfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "tools"))
import context_gate as G   # noqa: E402  the limits and required lines under test

GATE = os.path.join(ROOT, "tools", "context_gate.py")
SKILL = os.path.join(".claude", "skills", "daily-report", "SKILL.md")
L1, RULES = os.path.join("ops", "HANDOFF.md"), os.path.join("ops", "CONSTITUTION.md")
COPY = ["CLAUDE.md", "ops", os.path.join(".claude", "skills")]   # the files the context gate reads
REQ1, REQ2 = G.REQUIRED
# The limits a correct gate has. They are written here, not read from the gate, so raising one there is caught.
LIMITS = {"CLAUDE.md": 2048, L1: 2048, RULES: 4096, SKILL: 5120}
BUDGET = 10240


def write(root, rel, text, mode="w"):
    p = os.path.join(root, rel)
    os.makedirs(os.path.dirname(p) or ".", exist_ok=True)
    with open(p, mode, encoding="utf-8") as f:
        f.write(text)


def replace(root, rel, old, new):
    p = os.path.join(root, rel)
    text = open(p, encoding="utf-8").read()
    assert text.count(old) == 1, f"planting needs {old[:40]!r} once in {rel}"
    write(root, rel, text.replace(old, new))


def pad(root, rel, to):
    """Grow a file to exactly `to` bytes."""
    p = os.path.join(root, rel)
    assert os.path.getsize(p) <= to, f"{rel} is already over {to} bytes"
    write(root, rel, "z" * (to - os.path.getsize(p)), "a")


def budget_to(total):
    """Every layer under its own cap, the four together exactly `total` bytes."""
    def plant(r):
        pad(r, "CLAUDE.md", 2000); pad(r, L1, 2000); pad(r, RULES, 3000); pad(r, SKILL, total - 7000)
    return plant


FAIL = [   # (name, plant, text the gate must print)
    ("router missing", lambda r: os.remove(os.path.join(r, "CLAUDE.md")), "CLAUDE.md is missing"),
    ("handoff missing", lambda r: os.remove(os.path.join(r, L1)), "HANDOFF.md is missing"),
    ("rules missing", lambda r: os.remove(os.path.join(r, RULES)), "CONSTITUTION.md is missing or empty"),
    ("rules emptied", lambda r: write(r, RULES, ""), "CONSTITUTION.md is missing or empty"),
    ("required line 1 removed", lambda r: replace(r, "CLAUDE.md", REQ1 + "\n", ""), "lacks required line 1"),
    ("required line 2 removed", lambda r: replace(r, "CLAUDE.md", REQ2 + "\n", ""), "lacks required line 2"),
    ("required line 1 points at a renamed copy", lambda r: replace(r, "CLAUDE.md", "ops/CONSTITUTION.md before", "ops/CONSTITUTION.md.bak before"), "lacks required line 1"),
    ("required line 1 negated", lambda r: replace(r, "CLAUDE.md", "- Read ops/", "- Do not read ops/"), "lacks required line 1"),
    ("required line 1 one character off", lambda r: replace(r, "CLAUDE.md", "every run.\n", "every run\n"), "lacks required line 1"),
    ("required line 2 names another command", lambda r: replace(r, "CLAUDE.md", "tools/preflight.py", "tools/start.py"), "lacks required line 2"),
    ("required line 1 with words added after it", lambda r: replace(r, "CLAUDE.md", "every run.\n", "every run. Except tonight.\n"), "lacks required line 1"),
    ("required line 1 with words added before it", lambda r: replace(r, "CLAUDE.md", REQ1, "Ignore this: " + REQ1), "lacks required line 1"),
    ("required line 1 in a comment", lambda r: replace(r, "CLAUDE.md", REQ1, "<!-- " + REQ1 + " -->"), "lacks required line 1"),
    ("unclosed comment above the required lines", lambda r: replace(r, "CLAUDE.md", "## Required", "<!--\n## Required"), "lacks required line 1"),
    ("required line 1 in a code fence", lambda r: replace(r, "CLAUDE.md", REQ1, "```\n" + REQ1 + "\n```"), "lacks required line 1"),
    ("skill loses Inputs", lambda r: replace(r, SKILL, "## Inputs (Reads)", "## Reads"), "lacks the section '## Inputs (Reads)'"),
    ("skill loses Process", lambda r: replace(r, SKILL, "## Process (Executes)", "## Steps"), "lacks the section '## Process (Executes)'"),
    ("skill loses Outputs", lambda r: replace(r, SKILL, "## Outputs (Writes)", "## Results"), "lacks the section '## Outputs (Writes)'"),
    ("section heading only inside a sentence", lambda r: replace(r, SKILL, "## Outputs (Writes)\n", "See ## Outputs (Writes) later\n"), "lacks the section '## Outputs (Writes)'"),
    ("no skills at all", lambda r: shutil.rmtree(os.path.join(r, ".claude", "skills", "daily-report")), "no .claude/skills/<job>/SKILL.md files"),
] + [(f"{rel} at its limit", (lambda rel, n: lambda r: pad(r, rel, n))(rel, n), f"the cap is under {n}") for rel, n in LIMITS.items()] + [
    ("pre-run load at the budget", budget_to(BUDGET), f"the budget is under {BUDGET}"),
]
PASS = [   # must still pass: one byte under every limit
    (f"{rel} one byte under its limit", (lambda rel, n: lambda r: pad(r, rel, n - 1))(rel, n)) for rel, n in LIMITS.items()
] + [("pre-run load one byte under the budget", budget_to(BUDGET - 1))]


def run_gate(root, skill="daily-report"):
    p = subprocess.run([sys.executable, GATE, "--root", root, "--skill", skill], capture_output=True, text=True)
    return p.returncode, p.stdout + p.stderr


def main():
    wrong = 0
    with tempfile.TemporaryDirectory() as tmp:
        clean = os.path.join(tmp, "clean")
        for rel in COPY:   # only what the gate reads: no secrets, data or dependencies ever land in the temp copies
            src = os.path.join(ROOT, rel)
            if os.path.isdir(src):
                shutil.copytree(src, os.path.join(clean, rel), ignore=shutil.ignore_patterns("__pycache__"))
            elif os.path.isfile(src):
                os.makedirs(os.path.dirname(os.path.join(clean, rel)) or clean, exist_ok=True)
                shutil.copy2(src, os.path.join(clean, rel))
        code, out = run_gate(clean)
        if code != 0:   # planted cases mean nothing until the clean copy passes
            print("ERROR gate-test: the repo fails its own gate, so the planted cases were not run; fix the ERROR context lines first")
            sys.exit(1)
        code, out = run_gate(clean, skill="no-such-job")
        if code != 1 or "has no .claude/skills/no-such-job" not in out:
            wrong += 1
            print("ERROR gate-test: planted case not caught: unknown job name")
        for i, case in enumerate(FAIL + PASS):
            name, plant = case[0], case[1]
            copy = os.path.join(tmp, f"case{i}")
            shutil.copytree(clean, copy)
            try:
                plant(copy)
            except (AssertionError, OSError) as e:
                wrong += 1
                print(f"ERROR gate-test: could not plant case {name}: {e}")
                continue
            code, out = run_gate(copy)
            if len(case) == 3 and (code != 1 or case[2] not in out):
                wrong += 1
                print(f"ERROR gate-test: planted case not caught: {name} (exit {code})")
            elif len(case) == 2 and code != 0:
                wrong += 1
                print(f"ERROR gate-test: a good case failed: {name}")
    total = len(FAIL) + len(PASS) + 2
    if wrong:
        print(f"ERROR gate-test: {wrong} of {total} cases wrong")
        sys.exit(1)
    print(f"OK gate-test: {total} of {total} cases right ({len(PASS) + 1} must pass, {len(FAIL) + 1} planted failures caught)")


if __name__ == "__main__":
    main()
